#!/usr/bin/python
import sys, re, os
from multiprocessing.dummy import Pool as ThreadPool
from platform import system
from random import sample as rand
from platform import system
from colorama import Fore
from colorama import Style
from pprint import pprint
from colorama import init
init (autoreset=True)
fr = Fore.RED
fc = Fore.CYAN
fw = Fore.WHITE
fy = Fore.YELLOW
fg = Fore.GREEN
sd = Style.DIM
sn = Style.NORMAL
sb = Style.BRIGHT
#####################
try:
    import requests

except ImportError:
    print ("install Requests")
    exit(-1)

# Coded By Jay Maranatha Hutajulu
if system() == 'Linux':
    os.system('clear')
if system() == 'Windows':
    os.system('cls')
    os.system('color 4')

banner = '''

      ##    ###    ##    ##                                                 
      ##   ## ##    ##  ##                                                   
      ##  ##   ##    ####                                                    
      ## ##     ##    ##                                                     
##    ## #########    ##                                                     
##    ## ##     ##    ##                                                     
 ######  ##     ##    ##    

##     ## ##     ## ########    ###          ## ##     ## ##       ##     ## 
##     ## ##     ##    ##      ## ##         ## ##     ## ##       ##     ## 
##     ## ##     ##    ##     ##   ##        ## ##     ## ##       ##     ## 
######### ##     ##    ##    ##     ##       ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ######### ##    ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ##     ## ##    ## ##     ## ##       ##     ## 
##     ##  #######     ##    ##     ##  ######   #######  ########  #######  
                            
                    [NEW]Bing Dorker Scanner[Coded] Jay Hutajulu
                
\n'''.format (fy, sb)
print banner


def BingDorking(dork):
    try:

        # Get sites from bing

        dork = dork.strip()

        page = 1

        while page <= 1031:

            bing = "https://www.bing.com/search?q=" + str(dork) + "&go=Search&qs=ds&first=" + str(page) + "&FORM=PERE7"

            req = requests.get(bing, timeout=6)

            sites = re.findall('<h2><a href="(.*?)"', req.content)

            page += 20

            for site in sites:
                site = site.strip()

                https = re.findall('://(.*?)/', site)

                for http in https:
                    http = http.strip()
                    print "[+] NEW DOMAIN : http://" + http
                    open('sites.txt', 'a').write('http://' + http + '\n')


    except:
        pass


def main():
    ListStie = raw_input('Enter ur Dorks in txt file: ')
    ListStie = open(ListStie, 'r').readlines()
    for i in ListStie:
        try:
            i = i.strip()
            data = BingDorking(i)
            pool = ThreadPool(150)
            pool.map(BingDorking, ListStie)
            pool.close()
            pool.join()
        except:
            pass


if __name__ == '__main__':
    main()
