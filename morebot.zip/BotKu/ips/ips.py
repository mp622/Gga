#!/usr/bin/python
# Coded By Am!Ne
# priv8 !
import requests,re
import urllib
import socket
import os
from colorama import *
#import numpy as np
# colores
red = Fore.RED
green = Fore.GREEN
ylw = Fore.YELLOW
blue = Fore.BLUE
white = Fore.WHITE
os.system("cls")
try:
	os.mkdir("kids")
except:
	pass
def logo():
	print """        {} 
      ##    ###    ##    ##                                                 
      ##   ## ##    ##  ##                                                   
      ##  ##   ##    ####                                                    
      ## ##     ##    ##                                                     
##    ## #########    ##                                                     
##    ## ##     ##    ##                                                     
 ######  ##     ##    ##   

##     ## ##     ## ########    ###          ## ##     ## ##       ##     ## 
##     ## ##     ##    ##      ## ##         ## ##     ## ##       ##     ## 
##     ## ##     ##    ##     ##   ##        ## ##     ## ##       ##     ## 
######### ##     ##    ##    ##     ##       ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ######### ##    ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ##     ## ##    ## ##     ## ##       ##     ## 
##     ##  #######     ##    ##     ##  ######   #######  ########  ####### 
	""".format(ylw)
	print "\n"
logo()
print """{}1/ ip range from website
2/ ip range from list ips
3/ Grab sites from ip
4/ bing dorker
5/ bing dorker from country
6/ About
""".format(green)
# ip range from website lists
def website():
	lists = raw_input('{}list sites : '.format(blue))
	lists = open(lists,"r")
	for sites in lists.readlines():
		site = sites.strip()
		if "http" in site:
			site = site.replace("http://","")
		try:
			ip = socket.gethostbyname(site)
			ex = ip.split(".")
			for xx in range(1,255):
				ips = ip.replace(ex[3],str(xx))
				print ips
				save = open("kids/ips.txt","a")
				save.write(ips+"\n")
		except:
			pass
# ip range from ip lists
def ip():
	lists = raw_input('{}list ips : '.format(blue))
	lists = open(lists,"r")
	for ipp in lists:
		ip = ipp.strip()
		ex = ip.split(".")
		for xx in range(1,255):
			ips = ip.replace(ex[3],str(xx))
			print ips
			save = open("kids/ipss.txt","a")
			save.write(ips+"\n")
# Website Grab
def grab():
	lists = raw_input('{}list ips : '.format(blue))
	lists = open(lists,"r")
	Header = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
	sitess = []
	for ips in lists.readlines():
		ip = ips.strip()
		print red + " [ "+ip+" ]"
		for num in range(1,300,10):
			bing = "https://www.bing.com/search?q=ip%3a"+ip+"&first="+str(num)+"&FORM=PERE"
			get = requests.get(bing,headers=Header).content
			find = re.findall('<h2><a href="(.*?)"', get)
			for b in find:
				x = re.findall("//(.*?)/",b)
				for y in x:
					if y not in sitess:
						sitess.append(y)
						for alls in sitess:
							if "www." in alls:
								alls = alls.replace("www.","")
 							site = "http://"+alls
							save = open("kids/grabip.txt","a")
							save.write(site+"\n")
							print white + site
			if 'class="sb_pagN' not in get:
				break
def bing():
	dork = raw_input("dork : ")
	Header = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
	sitess = []
	for i in range(1,300,10):
		url = "https://www.bing.com/search?q="+dork+"&first="+str(i)+"&FORM=PERE"
		get = requests.get(url,headers=Header).content
		find = re.findall('<h2><a href="(.*?)"', get)
		for b in find:
			x = re.findall("//(.*?)/",b)
			for y in x:
				if y not in sitess:
					sitess.append(y)
					for alls in sitess:
						if "www." in alls:
							alls = alls.replace("www.","")
						site = "http://"+alls
						save = open("kids/grabs.txt","a")
						save.write(site+"\n")
						print white + site
		if 'class="sb_pagN' not in get:
			break
def bing_cntry():
	dork = raw_input("dork : ")
	Header = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:28.0) Gecko/20100101 Firefox/28.0'}
	domains = ['ac', 'ad', 'ae', 'af', 'ag', 'ai', 'al', 'am', 'an', 'ao',
                        'aq', 'ar', 'as', 'at', 'au', 'aw', 'ax', 'az', 'ba', 'bb',
                        'bd', 'be', 'bf', 'bg', 'bh', 'bi', 'bj', 'bm', 'bn', 'bo',
                        'br', 'bs', 'bt', 'bv', 'bw', 'by', 'bz', 'ca', 'cc', 'cd',
                        'cf', 'cg', 'ch', 'ci', 'ck', 'cl', 'cm', 'cn', 'co', 'cr',
                        'cu', 'cv', 'cx', 'cy', 'cz', 'de', 'dj', 'dk', 'dm', 'do',
                        'dz', 'ec', 'ee', 'eg', 'eh', 'er', 'es', 'et', 'eu', 'fi',
                        'fj', 'fk', 'fm', 'fo', 'fr', 'ga', 'gb', 'gd', 'ge', 'gf',
                        'gg', 'gh', 'gi', 'gl', 'gm', 'gn', 'gp', 'gq', 'gr', 'gs',
                        'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn', 'hr', 'ht', 'hu',
                        'id', 'ie', 'il', 'im', 'in', 'io', 'iq', 'is', 'it',
                        'je', 'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki', 'km', 'kn',
                        'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb', 'lc', 'li', 'lk',
                        'lr', 'ls', 'lt', 'lu', 'lv', 'ly', 'ma', 'mc', 'md', 'me',
                        'mg', 'mh', 'mk', 'ml', 'mm', 'mn', 'mo', 'mp', 'mq', 'mr',
                        'ms', 'mt', 'mu', 'mv', 'mw', 'mx', 'my', 'mz', 'na', 'nc',
                        'ne', 'nf', 'ng', 'ni', 'nl', 'no', 'np', 'nr', 'nu', 'nz',
                        'om', 'pa', 'pe', 'pf', 'pg', 'ph', 'pk', 'pl', 'pm', 'pn',
                        'pr', 'ps', 'pt', 'pw', 'py', 'qa', 're', 'ro', 'rs', 'ru',
                        'rw', 'sa', 'sb', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sj',
                        'sk', 'sl', 'sm', 'sn', 'so', 'sr', 'st', 'su', 'sv', 'sy',
                        'sz', 'tc', 'td', 'tf', 'tg', 'th', 'tj', 'tk', 'tl', 'tm',
                        'tn', 'to', 'tp', 'tr', 'tt', 'tv', 'tw', 'tz', 'ua', 'ug',
                        'uk', 'um', 'us', 'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi',
                        'vn', 'vu', 'wf', 'ws', 'ye', 'yt', 'za', 'zm', 'zw', 'com',
                        'net', 'org', 'biz', 'gov', 'mil', 'edu', 'info', 'int', 'tel',
                        'name', 'aero', 'asia', 'cat', 'coop', 'jobs', 'mobi', 'museum',
                        'pro', 'travel']
	sitess = []
	for dmn in domains:
		print ylw + "["+dmn+"]"
		for i in range(1,300,10):
			url = "https://www.bing.com/search?q="+dork+" site: "+dmn+"&first="+str(i)+"&FORM=PERE"
			get = requests.get(url,headers=Header).content
			find = re.findall('<h2><a href="(.*?)"', get)
			for b in find:
				x = re.findall("//(.*?)/",b)
				for y in x:
					if y not in sitess:
						sitess.append(y)
						for alls in sitess:
							if "www." in alls:
								alls = alls.replace("www.","")
							site = "http://"+alls
							save = open("kids/grabscntry.txt","a")
							save.write(site+"\n")
							print white + site
			if 'class="sb_pagN' not in get:
				break         
def about():
	print """{0} Coded By Jay Maranatha Hutajulu
	{1} https://t.me/jaygantengz """.format(ylw,green)            
x = raw_input("root@./barbarking:")
if x == "1":
	website()
if x == "2":
	ip()
if x == "3":
	grab()
if x == "4":
	bing()
if x == "5":
	bing_cntry()
if x == "6":
	about()