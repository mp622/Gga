#Get Wordpress SiteList 
#!/usr/bin/python
# -*- coding: utf-8 -*
# Jay Maranatha Hutajulu
# Get List Site Wordpress          
#DONATE ME :(
	# PERFECT MONEY  = U21799109
##############################
import sys, os, re, socket, binascii, time, json, random, threading, Queue, pprint, urlparse, smtplib, telnetlib, os.path, hashlib, string, urllib2, glob, sqlite3, urllib, argparse, marshal, base64, colorama, requests
from time import time as timer  
from re import findall as reg
year = time.strftime("%d/%m/%y")


banner =  """
      \033       
      ##    ###    ##    ##                                                 
      ##   ## ##    ##  ##                                                   
      ##  ##   ##    ####                                                    
      ## ##     ##    ##                                                     
##    ## #########    ##                                                     
##    ## ##     ##    ##                                                     
 ######  ##     ##    ##   

##     ## ##     ## ########    ###          ## ##     ## ##       ##     ## 
##     ## ##     ##    ##      ## ##         ## ##     ## ##       ##     ## 
##     ## ##     ##    ##     ##   ##        ## ##     ## ##       ##     ## 
######### ##     ##    ##    ##     ##       ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ######### ##    ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ##     ## ##    ## ##     ## ##       ##     ## 
##     ##  #######     ##    ##     ##  ######   #######  ########  #######  

                     {[NEW]Grab WordPress Site Only [Coded] Jay Hutajulu} 
"""
print banner


epp = raw_input('\033[0mTheme WP Name@ ~#: ')
pagr = raw_input('\033[0mPage(2-999)@ ~#: ')

print('\033[33mOn The Way To Grab Site WP CUSSSSSSSSS !!! ')

for page in range(1, int(pagr)):
	state = ['us1', 'us2', 'us3', 'us4', 'us5', 'us6', 'us7', 'us8', 'us9', 'us10', 'us11', 'us12', 'us13', 'us14', 'us15', 'eu1', 'eu2', 'eu3', 'eu4', 'eu5', 'eu6', 'eu7', 'eu8', 'eu9', 'eu10']
	proxy = random.choice(state)
	ua = {'Origin': 'https://' + proxy + '.proxysite.com', 
	'Upgrade-Insecure-Requests': '1',
	'Referer': 'https://' + proxy + '.proxysite.com/process.php?d=QLra7hUZyu%2F7SPpzJIj5Yfs%3D&b=1&f=norefer',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Content-Type': 'application/x-www-form-urlencoded',
	'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36',
	'Cookies': '_ga=GA1.2.589987225.1610038351; __gads=ID=bffe8a3c85dbe9de-228786b28fc5007f:T=1610038351:RT=1610038351:S=ALNI_Mbo8XuMGTbG0cfECZhdrpKMLkcBLA; _gid=GA1.2.1432847235.1623704158; c[themetix.com][/][IDE]=AHWqTUl0Im-eLYq4upcs9o_5nQC64Q4uAjr0LgWExpANROqkTn8bXVdImvD2PNcP'
	}
	data = {'allowCookies': 'on',A
      'd': 'https://themetix.com/' +epp+'/'+str(page)}
	test = requests.post('https://' + proxy + '.proxysite.com/includes/process.php?action=update', data=data, headers=ua, timeout=10)
	if 'site' in test.content:
		print('\033[0m[WAIT] Is Only Turning the Only Proxy :) '+ ' ' + proxy) 
		domen = reg('<p style="margin-bottom: 20px">(.*?)</p>', test.content)
		for cc in domen:
			print(str(cc)+'\033[32m [!] SUCCESS Jay Ganteng  . . .')
			open('wp-jay.txt','a').write('https://'+cc+'\n')