#!/bin/bash
blue='\e[0;34'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'

touch grabdomain-jay.txt
clear
banner(){
echo -e $pink" __  __                ____           _     _"
echo -e $pink"|  \/  | __ _ ___ ___ / ___|_ __ __ _| |__ | |__   ___ _ __"
echo -e $pink"| |\/| |/ _- / __/ __| |  _| -__/ _- | -_ \| -_ \ / _ \ -__|"
echo -e $pink"| |  | | (_| \__ \__ \ |_| | | | (_| | |_) | |_) |  __/ |"
echo -e $pink"  |_|  |_|\__,_|___/___/\____|_|  \__,_|_.__/|_.__/ \___|_|

     ██╗ █████╗ ██╗   ██╗                                           
     ██║██╔══██╗╚██╗ ██╔╝                                           
     ██║███████║ ╚████╔╝                                            
██   ██║██╔══██║  ╚██╔╝                                             
╚█████╔╝██║  ██║   ██║                                              
 ╚════╝ ╚═╝  ╚═╝   ╚═╝                                              
                                                                    
██╗  ██╗██╗   ██╗████████╗ █████╗      ██╗██╗   ██╗██╗     ██╗   ██╗
██║  ██║██║   ██║╚══██╔══╝██╔══██╗     ██║██║   ██║██║     ██║   ██║
███████║██║   ██║   ██║   ███████║     ██║██║   ██║██║     ██║   ██║
██╔══██║██║   ██║   ██║   ██╔══██║██   ██║██║   ██║██║     ██║   ██║
██║  ██║╚██████╔╝   ██║   ██║  ██║╚█████╔╝╚██████╔╝███████╗╚██████╔╝
╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝ ╚════╝  ╚═════╝ ╚══════╝ ╚═════╝ 
                                                                    
    {Grab Domain V1 New API [Coded] Jay Hutajulu}
     "
read -p "angka (1-100) => " domain
read -p "page => " hal1;
read -p "To page => " hal2
}
banner
for((i=$hal1;i<=$hal2;i++))
do
curr=$(curl -s "https://com.all-url.info/$domain/$i/" | grep -oP '<a href=https://com.all-url.info/com/(.*?)>(.*?)</a>' | cut -d "<" -f2 | cut -d ">" -f2)
c=$(echo "$curr" | wc -l)
b=$(cat grabdomain-jay.txt | wc -l 2>/dev/null)
if [[ $curr =~ '.com' ]]; then
echo "$curr" >> grabdomain-jay.txt
echo -e "\033[42;1m -- \033[0m ${okegreen} [+]Found $c Diangka $domain|$i|$b"
else
echo -e "\033[41;1m -- \033[0m ${red} [-]Error $c Diangka $domain|$i|$b"
fi
done
