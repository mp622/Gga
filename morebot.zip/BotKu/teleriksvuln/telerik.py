import requests
import sys
import platform
import os
from platform import system
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
def banner():
    print("""
      ##    ###    ##    ##                                                 
      ##   ## ##    ##  ##                                                   
      ##  ##   ##    ####                                                    
      ## ##     ##    ##                                                     
##    ## #########    ##                                                     
##    ## ##     ##    ##                                                     
 ######  ##     ##    ##    

##     ## ##     ## ########    ###          ## ##     ## ##       ##     ## 
##     ## ##     ##    ##      ## ##         ## ##     ## ##       ##     ## 
##     ## ##     ##    ##     ##   ##        ## ##     ## ##       ##     ## 
######### ##     ##    ##    ##     ##       ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ######### ##    ## ##     ## ##       ##     ## 
##     ## ##     ##    ##    ##     ## ##    ## ##     ## ##       ##     ## 
##     ##  #######     ##    ##     ##  ######   #######  ########  #######  
                            
                    [NEW] Telerik Mass Scanner Key Vuln[Coded] Jay Hutajulu
    """)
def clear():
    if system() == "Linux":
        os.system("clear")
    else:
        os.system("cls")
clear()
banner()
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
listkontol = raw_input("\033[32m[\033[37m!\033[32m]\033[37m Website list: ")
listSite = listkontol
op = [i.strip() for i in open(listSite, "r").readlines()]
 
def check(site):
  try:
    r = requests.get(site + "/DesktopModules/Admin/RadEditorProvider/DialogHandler.aspx", verify=False, timeout=10)
    ff = open("vuln.txt", "a+")
    if "Loading the dialog" in r.text:
      print("\033[37m" + site + "/DesktopModules/Admin/RadEditorProvider/DialogHandler.aspx\033[37m > \033[32mVULN")
      ff.write(site + "/DesktopModules/Admin/RadEditorProvider/DialogHandler.aspx\n")
    else:
      c = requests.get(site + "/providers/htmleditorproviders/telerik/telerik.web.ui.dialoghandler.aspx", verify=False, timeout=10)
      if "Loading the dialog" in c.text:
        print("\033[37m" + site + "/providers/htmleditorproviders/telerik/telerik.web.ui.dialoghandler.aspx\033[37m > \033[32mVULN")
        ff.write(site + "/providers/htmleditorproviders/telerik/telerik.web.ui.dialoghandler.aspx\n")
      else:
        b = requests.get(site + "/desktopmodules/telerikwebui/radeditorprovider/telerik.web.ui.dialoghandler.aspx", verify=False, timeout=10)
        if "Loading the dialog" in b.text:
          print("\033[37m" + site + "/desktopmodules/telerikwebui/radeditorprovider/telerik.web.ui.dialoghandler.aspx\033[37m > \033[32mVULN")
          ff.write(site + "/desktopmodules/telerikwebui/radeditorprovider/telerik.web.ui.dialoghandler.aspx\n")
        else:
          k = requests.get(site + "/desktopmodules/dnnwerk.radeditorprovider/dialoghandler.aspx", verify=False, timeout=10)
          if "Loading the dialog" in k.text:
            print("\033[37m" + site + "/desktopmodules/dnnwerk.radeditorprovider/dialoghandler.aspx\033[37m > \033[32mVULN")
            ff.write(site + "/desktopmodules/dnnwerk.radeditorprovider/dialoghandler.aspx\n")
          else:
            print("\033[37m" + site + "\033[37m > \033[31mFAIL!")
  except:
    print("\033[37m" + site + "\033[37m > \033[31mERRN!")
 
tod = Pool(150)
tod.map(check, op)
tod.close()
tod.join()